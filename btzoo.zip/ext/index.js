
// const baseUrl = 'https://btczoo.co';
const baseUrl = 'http://124.221.133.213:8099';
// const baseUrl = 'http://localhost:8099';
const demoUrlStr = baseUrl+'/ttt/syDemo';
const projectUrlStr = baseUrl+'/ttt/syPro';

const connectButton = document.getElementById("connectBtn")
const mintButton1 = document.getElementById("mintBtn")
mintButton1.onclick = mint
connectButton.onclick = connect

let userName = '';
let sun = 100000000;
let address = '';

let buttonText = 'Connect Wallet';
let buttonDisable = false;
let toastrType = 'success';
let toastrText = 'Please Connect Wallet';
let proJudgeIsDisable = false;
// 0 ：normal -1 ：unStart 1 :ended 9: exceeded
let proJudgeIsDisableState = 0;

// 倒计时需要用的js
$.exists = function(selector) {
  return ($(selector).length > 0);
}

/*
window.updatedProItem = function (proItem) {
  if ($.exists('#tm-if-expired')) {
    // Set the date we're counting down to tm-if-expired
    var startDate = new Date('2019-05-30 23:59:59').getTime();
    var endDate = new Date('2019-05-30 23:59:59').getTime();

    var x = 0;
    var y = 0;
    var finalX = 0;
    var total = 1;
    let barValuePer = '0%'
    let barValue = '0/0'

    if (null != proItem) {
      startDate = proItem.start;
      endDate = proItem.end;
      x = proItem.x;
      y = proItem.y;
      total = proItem.total;
      finalX = x>y?x:y;
      if (finalX>total){
        finalX = Number(total);
      }

      barValuePer = finalX/total;
      barValue ='Sale Progress : ' + finalX +'  /  ' + total;
    }

    // Update the count down every 1 second
    var x = setInterval(function() {

      // Get todays date and time
      var now = new Date().getTime();

      // Find the distance between now an the count down date
      var distanceStart = startDate - now;
      var distanceEnd = endDate - now;

      // Time calculations for days, hours, minutes and seconds
      var days = 0;
      var hours = 0;
      var minutes = 0;
      var seconds = 0;



      // Not started
      if (distanceStart > 0 ){
        document.getElementById("projectText").innerHTML = 'Token Sale Not Started.';
        proJudgeIsDisable = true;
        proJudgeIsDisableState = -1;
      }else {
        // already begun
        if (distanceEnd < 0) {
          // end
          clearInterval(x);
          document.getElementById("projectText").innerHTML = "Token Sale Is Over.";
          proJudgeIsDisable = true;
          proJudgeIsDisableState = 1;
        }else{
          // Ongoing
          // Time calculations for days, hours, minutes and seconds
          days = Math.floor(distanceEnd / (1000 * 60 * 60 * 24));
          hours = Math.floor((distanceEnd % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          minutes = Math.floor((distanceEnd % (1000 * 60 * 60)) / (1000 * 60));
          seconds = Math.floor((distanceEnd % (1000 * 60)) / 1000);
        }
      }

      // Output the result in an element with id="demo"
      document.getElementById("tm-count-days").innerHTML = days;
      document.getElementById("tm-count-hours").innerHTML = hours;
      document.getElementById("tm-count-minutes").innerHTML = minutes;
      document.getElementById("tm-count-seconds").innerHTML = seconds;

      /!*if (barValuePer == 0){
        document.getElementById("barValuePer").innerHTML = '';
        document.getElementById("barValue").innerHTML = '';
      }else{


      }*!/
      document.getElementById("barValuePer").innerHTML = barValuePer*100 +'%';
      document.getElementById("barValue").innerHTML = barValue;

      // 若值大于1 ，则只显示1
      // if (barValuePer>1){
      //   barValuePer = 1;
      // }
      $('#barDiv').css('width',barValuePer*100 +'%');

      // 若 等于1 ，则销售满了，需要禁止
      if(barValuePer == 1){
        proJudgeIsDisable = true;
        proJudgeIsDisableState = 9;
      }
      // setMiniBtn(isDisable)
    }, 1000);
  }
}
*/

async function connect() {
  try {
    let accounts = await window.unisat.requestAccounts();
    console.log('connect success', accounts);
    address = accounts[0];
    setUserName(address);
    try {
      let res = await window.unisat.getBalance();
      console.log(res)
      setTotalMoney(res.total)
      getAddress(address);

    } catch (e) {
      console.log(e);
    }

  } catch (e) {
    console.log('connect failed');
  }
}
       
async function mint() {
  // 判断 项目状态，若超时则 不调用

  // if (proJudgeIsDisable) {
  //   switch (proJudgeIsDisableState) {
  //     case -1:
  //       commonUtil.message('Sorry, the sale hasn\'t start.', 'danger');
  //       break;
  //     case 1:
  //       commonUtil.message('Sorry, the sale has ended.', 'danger');
  //       break;
  //     case 9:
  //       commonUtil.message('Sorry, the sale has exceeded.', 'danger');
  //       break;
  //   }
  //   return;
  // }

  try {
    let txid = await window.unisat.sendBitcoin("bc1pf9770d3khxqwtpx07m3ql8klmymtaarphu986vmzm79ajcm3j4rq4tyc09",10000);
    // let txid =1;
    updateAddress(address, txid);

    console.log(txid)
  } catch (e) {
    console.log(e);

    toastrText = 'User Rejected The Transaction.';
    toastrType = 'danger';
    commonUtil.message(toastrText, toastrType);
  }

}

function setUserName(address){
  const addressTemp = address;

  const startStr = addressTemp.substring(0, 4);
  const endStr = addressTemp.substring(addressTemp.length - 4);

  const newStr = startStr + "..." + endStr;
  userName = newStr;
  localStorage.setItem("userName", newStr);
  connectButton.innerHTML = newStr;
}

function setTotalMoney(total){
  const totalMoney = document.getElementById("totalMoney")

  let balances = total / sun
  const strToRender = balances || "0.0000";

  totalMoney.innerHTML = 'Your Balance  : ' + String(strToRender).replace(/^(.*\..{4}).*$/,"$1")  +' BTC' ;
}

function getAddress(accounts){
  $.ajax({
    url: demoUrlStr + '/get20231214',
    type: 'POST',
    data: JSON.stringify({"address": accounts}),
    dataType: 'json',
    contentType: 'application/json',
    headers: {
      'Access-Control-Allow-Origin': '*',
      'ttToken': myEncrypt()
    },
    success: function (resultRes) {
      // 请求成功后的处理
      console.log(resultRes);
      setButtonTeam(resultRes);
    },
    error: function (xhr, textStatus, errorThrown) {
      // 请求失败后的处理
      console.log(666666);
    }
  });
}

function getAllOrder(){
  $.ajax({
    url: demoUrlStr + '/getAllOrder',
    type: 'GET',
    dataType: 'json',
    contentType: 'application/json',
    headers: {
      'Access-Control-Allow-Origin': '*',
      'ttToken': myEncrypt()
    },
    success: function (resultRes) {
      // 请求成功后的处理
      console.log(resultRes);
      console.log(12121);
      updateOrderNum(resultRes);
    },
    error: function (xhr, textStatus, errorThrown) {
      // 请求失败后的处理
      console.log(666666);
    }
  });
}


window.getProject = function(){
  let proId = 1;

  $.ajax({
    url: projectUrlStr + '/get/'+proId,
    type: 'GET',
    // data: JSON.stringify({"address": accounts}),
    // dataType: 'json',
    // contentType: 'application/json',
    headers: {
      'Access-Control-Allow-Origin': '*',
      'ttToken': myEncrypt()
    },
    success: function (resultRes) {
      // 请求成功后的处理
      console.log(resultRes);
      debugger
      getAllOrder();
      // updatedProItem(resultRes.data)
      // setButtonTeam(resultRes);
    },
    error: function (xhr, textStatus, errorThrown) {
      // 请求失败后的处理
      console.log(666666);
      // updatedProItem(null)
    }
  });
}

function updateAddress(accounts,txid){
  $.ajax({
    url: demoUrlStr + '/add20231214',
    type: 'POST',
    data: JSON.stringify({"address": accounts,"txid": txid,"b":1}),
    dataType: 'json',
    contentType: 'application/json',
    headers: {
      'Access-Control-Allow-Origin': '*',
      'ttToken': myEncrypt()
    },
    success: function (resultRes) {
      // 请求成功后的处理
      console.log("更新成功",resultRes);

      toastrText = 'Mint Success, Tx:'+ txid;
      commonUtil.message(toastrText);

      buttonDisable = true;
      $('#mintBtn').text('Alredy Minted')
      $('#mintBtn').prop('disabled', buttonDisable);
      if (buttonDisable){
        $('#mintBtn').addClass('buttonDisable');
      }else{
        $('#mintBtn').removeClass('buttonDisable');
      }
    },
    error: function (xhr, textStatus, errorThrown) {
      // 请求失败后的处理
      console.log(666666);
    }
  });
}

// 更新金额
function updateOrderNum(resultRes){
  if (resultRes.code === 0) {
    debugger
    let data = resultRes.data
    const totalMoney2 = document.getElementById("totalMoney2")
    var fenzi =  data.isPlayReally;
    var fenmu =data.isPlayTotal;
    totalMoney2.innerHTML = 'Mint Progress  : '+ fenzi + " / "+fenmu ;
  }else{
    totalMoney2.innerHTML = 'Mint Progress  : 0/800';
  }
}


// 控制 按钮情况
function setButtonTeam(resultRes){
  if (resultRes.code === 0) {
    let data = resultRes.data
    if (data.b === 0) {
      toastrType = 'success'
      toastrText = 'Connect Success.'
      buttonDisable = false;
      buttonText = ' Mint '

      // const totalMoney2 = document.getElementById("totalMoney2")
      // var fenzi = 0;
      // var fenmu = 0;
      // totalMoney2.innerHTML = 'Mint Progress  : '+ fenzi + " / "+fenmu ;
      // getAllOrder();
    } else if (data.b === 1) {
      toastrType = 'warning'
      toastrText = 'Oops, Your Address Has Alredy Minted'
      buttonDisable = true;
      buttonText = 'Alredy Minted'
    }
  } else {
    toastrType = 'danger'
    toastrText = 'Oops, Your Address Not Whitelisted.'
    buttonDisable = true;
    buttonText = 'Not Whitelisted'
  }

  commonUtil.message(toastrText,toastrType);

  $('#mintBtn').text(buttonText)

  setMiniBtn(buttonDisable)
}

function setMiniBtn(buttonDisable) {
  $('#mintBtn').prop('disabled', buttonDisable || proJudgeIsDisable);

  if (buttonDisable || proJudgeIsDisable) {
    $('#mintBtn').addClass('buttonDisable');
    /*if (!proJudgeIsDisable){
      // $('#mintBtn').addClass('buttonMini');
      // 若钱包可用，但 项目处于不可用期间，需要mini变宽，否则
      $('#mintBtn').removeClass('buttonMini');
    } else */

    // 只 连接成功时按钮显示mini，都需要addClass，
    if (!buttonDisable) {
      $('#mintBtn').addClass('buttonMini');
      if(proJudgeIsDisable){
        $('#mintBtn').prop('disabled', !proJudgeIsDisable);
      }
    }else{
      $('#mintBtn').removeClass('buttonMini');
    }
  } else {
    $('#mintBtn').removeClass('buttonDisable');
    $('#mintBtn').addClass('buttonMini');
  }
}
/* 加密方法 */
window.myEncrypt = function () {

  const word = new Date().getTime() + ',abcd';
  const key = CryptoJS.enc.Utf8.parse("1234567890hijklm"); // 十六位十六进制数作为密钥
  const iv = CryptoJS.enc.Utf8.parse('1234567890abcdef'); // 十六位十六进制数作为密钥偏移量

  const srcs = CryptoJS.enc.Utf8.parse(word);
  const encrypted = CryptoJS.AES.encrypt(srcs, key, {
    iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });

  return CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
}

window.onload = function() {
  /*var connectBtn6 = document.querySelector('#connectBtn')
  var bubian = 0
  connectBtn6.addEventListener('click',function(){

    bubian += 1
    localStorage.setItem("di1",  bubian);
  })

  const storedStr66 = localStorage.getItem("di1");
  console.log(storedStr66);
  if(storedStr66 > 0){
    // 从本地存储中获取存储的字符串
    const storedStr = localStorage.getItem("di");


  }*/

  localStorage.removeItem("userName");

  userName =  localStorage.getItem("userName");
  // 如果存储的值为 null，则设置为默认值
  const strToRender = userName || "Connect Wallet";
  // 渲染本地存储的内容
  connectButton.innerHTML = strToRender;

}